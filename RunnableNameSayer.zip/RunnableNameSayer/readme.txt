To run NameSayer:
1) Make sure ffmpeg is installed on this machine
2) Open terminal from/set terminal directory to this directory (the directory with "NameSayer.jar" and "names").
3) type "java -jar NameSayer.jar" into terminal and execute.
