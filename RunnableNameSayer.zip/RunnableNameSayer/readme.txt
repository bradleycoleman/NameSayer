To run NameSayer:
1) Make sure ffmpeg is installed on this machine
2) Open terminal and set directory to this directory (the directory with "NameSayer.jar" and "names").
3) type "java -jar NameSayerApp.jar" into terminal and execute.
